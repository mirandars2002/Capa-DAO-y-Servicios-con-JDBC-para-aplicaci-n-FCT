package ceufct.services;

public class RegistroServiceException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public RegistroServiceException() {
		// TODO Auto-generated constructor stub
	}

	public RegistroServiceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public RegistroServiceException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public RegistroServiceException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public RegistroServiceException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
