package ceufct.services;

public class UsuarioServiceException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2130457373195477808L;

	public UsuarioServiceException() {
		// TODO Auto-generated constructor stub
	}

	public UsuarioServiceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public UsuarioServiceException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public UsuarioServiceException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public UsuarioServiceException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
